package com.example.projeto1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
